/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Location_Info;

/**
 *
 * @author Anirudh
 */
public class City {
    private String cityName;

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String CityName) {
        this.cityName = CityName;
    }
    
    @Override
    public String toString(){
        return this.cityName;
    }
    
}
